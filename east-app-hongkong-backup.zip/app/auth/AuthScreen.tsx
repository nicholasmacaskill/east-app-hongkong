'use client';
import React, { useState, useCallback } from 'react';
import { User, Mail, Lock, Phone, LogIn, CheckCircle } from 'lucide-react';
import Link from 'next/link';
import { supabase } from '@/app/lib/supabase';
import type { UserRole } from '../types';

type AuthStep = 'login' | 'register' | 'success';

interface FormData {
    fullName: string;
    email: string;
    password: string;
    confirmPassword: string;
    phone: string;
    role: 'player' | 'parent' | 'coach';
}

const initialFormData: FormData = {
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phone: '',
    role: 'player',
};

interface AuthScreenProps {
    onAuthSuccess: (role: UserRole) => void;
    expectedRole?: UserRole;
}

const AuthHeader = ({ title }: { title: string }) => (
    <div className="text-center mb-6">
        {/* Logo */}
        <h2 className="text-xl font-bold italic text-gray-400 uppercase tracking-widest mt-4">{title}</h2>
    </div>
);

const InputField: React.FC<{ label: string; name: keyof FormData; type: string; value: string; icon: React.ElementType; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; placeholder: string; }> = ({ label, name, type, value, icon: Icon, onChange, placeholder }) => (
    <div className="relative mb-4">
        <label htmlFor={name} className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1">{label}</label>
        <div className="relative">
            <Icon size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-east-light" />
            <input type={type} id={name} name={name} value={value} onChange={onChange} placeholder={placeholder} required className="w-full bg-gray-800 text-white border border-gray-700 rounded-lg py-3 pl-10 pr-4 focus:border-east-light focus:ring-1 focus:ring-east-light transition-colors placeholder:text-gray-500" />
        </div>
    </div>
);

export default function AuthScreen({ onAuthSuccess, expectedRole }: AuthScreenProps) {
    const [step, setStep] = useState<AuthStep>('login');
    const [formData, setFormData] = useState<FormData>({
        ...initialFormData,
        role: (expectedRole === 'parent' || expectedRole === 'coach' || expectedRole === 'player') ? expectedRole : 'player'
    });
    const [loading, setLoading] = useState(false);

    const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    }, []);

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        const { data, error } = await supabase.auth.signInWithPassword({
            email: formData.email,
            password: formData.password,
        });

        if (error) {
            alert(error.message);
            setLoading(false);
        } else if (data.user) {
            // Fetch role from profile
            const { data: profile } = await supabase
                .from('profiles')
                .select('role')
                .eq('id', data.user.id)
                .single();

            onAuthSuccess((profile?.role as UserRole) || 'player');
        }
    };

    const handleRegister = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        const { data, error } = await supabase.auth.signUp({
            email: formData.email,
            password: formData.password,
            options: {
                data: {
                    full_name: formData.fullName,
                    mobile: formData.phone,
                    role: formData.role
                }
            }
        });

        if (error) {
            alert(error.message);
            setLoading(false);
        } else {
            // Send welcome email
            if (data.user?.id) {
                try {
                    await fetch('/api/auth/send-welcome-email', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ userId: data.user.id })
                    });
                } catch (emailErr) {
                    console.error('Welcome email failed:', emailErr);
                    // Don't block registration if email fails
                }
            }

            // Check for immediate session
            if (data.session) {
                onAuthSuccess(formData.role);
            } else {
                // Try immediate login
                const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
                    email: formData.email,
                    password: formData.password,
                });

                if (loginData?.session) {
                    onAuthSuccess(formData.role);
                } else {
                    setStep('success');
                }
            }
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4 relative overflow-hidden">
            {/* Background Image Layer */}
            <div className="fixed inset-0 z-0">
                <img
                    src="https://images.unsplash.com/photo-1580748141549-71748ddf0bdc?auto=format&fit=crop&q=80&w=1200"
                    className="w-full h-full object-cover opacity-20 grayscale"
                    alt="bg"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/50 to-black/90" />
            </div>

            <div className="w-full max-w-sm bg-[#0a0a0a] rounded-2xl p-8 shadow-2xl border border-gray-800 animate-fadeIn relative z-10">

                {/* --- LOGIN --- */}
                {step === 'login' && (
                    <>
                        <AuthHeader title={expectedRole === 'admin' ? "Admin Portal Access" : "Member Login"} />
                        <form onSubmit={handleLogin}>
                            <InputField label="Email Address" name="email" type="email" value={formData.email} icon={Mail} onChange={handleChange} placeholder="Enter your email" />
                            <InputField label="Password" name="password" type="password" value={formData.password} icon={Lock} onChange={handleChange} placeholder="Enter your password" />
                            <button type="submit" disabled={loading} className="w-full bg-east-light text-black font-montserrat font-black italic text-lg py-3 rounded-full uppercase tracking-wider shadow-lg hover:bg-east-dark hover:text-white transition-all disabled:opacity-50 mt-2">
                                {loading ? 'LOGGING IN...' : 'LOGIN'}
                            </button>
                        </form>
                        <div className="text-center mt-6 space-y-3">
                            {expectedRole !== 'admin' && (
                                <p className="text-sm text-gray-400">Need an account? <button onClick={() => setStep('register')} className="text-east-light underline font-bold hover:text-white transition-colors">Register Now</button></p>
                            )}
                            <Link href="/forgot-password" className="text-[10px] text-gray-500 hover:text-east-light transition-colors uppercase tracking-wider block">Forgot Password?</Link>
                        </div>
                    </>
                )}

                {/* --- REGISTER (SINGLE STEP) --- */}
                {step === 'register' && (
                    <>
                        <AuthHeader title="Create Account" />
                        <form onSubmit={handleRegister}>
                            <InputField label="Full Name" name="fullName" type="text" value={formData.fullName} icon={User} onChange={handleChange} placeholder="First and Last Name" />
                            <InputField label="Mobile Number" name="phone" type="tel" value={formData.phone} icon={Phone} onChange={handleChange} placeholder="+852 1234 5678" />
                            <InputField label="Email Address" name="email" type="email" value={formData.email} icon={Mail} onChange={handleChange} placeholder="Enter email" />
                            <InputField label="Password" name="password" type="password" value={formData.password} icon={Lock} onChange={handleChange} placeholder="Create password" />
                            <button type="submit" disabled={loading} className="w-full bg-east-light text-black font-montserrat font-black italic text-lg py-3 rounded-full uppercase tracking-wider shadow-lg hover:bg-east-dark hover:text-white transition-all disabled:opacity-50 mt-2">
                                {loading ? 'CREATING ACCT...' : 'CREATE ACCOUNT'}
                            </button>
                        </form>
                        <button onClick={() => setStep('login')} className="w-full text-center text-gray-500 text-xs mt-4 hover:text-white uppercase tracking-widest">Back to Login</button>
                    </>
                )}

                {/* --- SUCCESS --- */}
                {step === 'success' && (
                    <div className="text-center py-4">
                        <CheckCircle size={80} className="text-east-light mx-auto mb-6 animate-bounce" />
                        <h2 className="font-montserrat font-black italic text-2xl text-white tracking-tighter mb-4 uppercase">WELCOME TO EAST</h2>
                        <p className="text-sm text-gray-400 mb-8">Your account has been created! Please check your email to confirm your address before logging in.</p>
                        <button onClick={() => setStep('login')} className="w-full bg-east-light text-black font-montserrat font-black italic text-lg py-3 rounded-full uppercase tracking-wider shadow-lg hover:bg-east-dark hover:text-white transition-all">
                            GO TO LOGIN
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}